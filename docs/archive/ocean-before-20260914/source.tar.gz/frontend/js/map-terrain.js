/* global window, document */
(function (G) {
  'use strict';
  // Fixed world-space fields keep the same terrain under every zoom and viewport.
  var palette = { soil: [83, 73, 61], grass: [157, 169, 126] };
  function clamp(v) { return Math.max(0, Math.min(1, v)); }
  function smooth(a, b, v) { v = clamp((v - a) / (b - a)); return v * v * (3 - 2 * v); }
  function hash(x, y) {
    var n = Math.imul(x, 374761393) + Math.imul(y, 668265263);
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
  }
  function noise(x, y) {
    var ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    var a = hash(ix, iy), b = hash(ix + 1, iy), c = hash(ix, iy + 1), d = hash(ix + 1, iy + 1);
    return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
  }
  function sample(x, y, size) {
    var u = clamp(x / size), v = clamp(y / size);
    var broad = noise(u * 7 + 13, v * 7 + 41);
    var detail = noise(u * 43 + 71, v * 43 + 17);
    var grass = smooth(.27, .74, noise(u * 12 + 9, v * 12 + 3) * .75 + detail * .25);
    return { grass: grass, relief: detail * .65 + broad * .35 };
  }
  function region(x, y, size) {
    var p = sample(x, y, size);
    return p.grass > .5 ? '浅草地' : '黑土地';
  }
  function create(size) {
    var canvas = document.createElement('canvas'), resolution = 2048, fieldSize = 257;
    canvas.width = canvas.height = resolution;
    var ctx = canvas.getContext('2d'), pixels = ctx.createImageData(resolution, resolution);
    var field = new Float32Array(fieldSize * fieldSize * 2);
    // Calculate ground variation on a coarse field, then interpolate pixels for seamless edges.
    for (var y = 0; y < fieldSize; y++) for (var x = 0; x < fieldSize; x++) {
      var p = sample(x / 256 * size, y / 256 * size, size), index = (y * fieldSize + x) * 2;
      field[index] = p.grass; field[index + 1] = p.relief;
    }
    for (var py = 0; py < resolution; py++) for (var px = 0; px < resolution; px++) {
      var fx = px / 8, fy = py / 8, ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy;
      var base = (iy * fieldSize + ix) * 2, values = [];
      for (var channel = 0; channel < 2; channel++) {
        var top = field[base + channel] * (1 - tx) + field[base + 2 + channel] * tx;
        var bottom = field[base + fieldSize * 2 + channel] * (1 - tx) + field[base + fieldSize * 2 + 2 + channel] * tx;
        values[channel] = top * (1 - ty) + bottom * ty;
      }
      var grain = hash(px + 101, py + 301) - .5;
      var shade = (values[1] - .5) * 19 + grain * 6;
      var offset = (py * resolution + px) * 4;
      for (var c = 0; c < 3; c++) {
        var land = palette.soil[c] + (palette.grass[c] - palette.soil[c]) * values[0];
        pixels.data[offset + c] = Math.round(land + shade);
      }
      pixels.data[offset + 3] = 255;
    }
    ctx.putImageData(pixels, 0, 0);
    return canvas;
  }
  var tileSpan = 4, density = 64, padding = 2;
  function createTile(cx, cy, size) {
    var side = tileSpan * density + padding * 2, stride = side + 2;
    var startX = cx * tileSpan * density - padding, startY = cy * tileSpan * density - padding;
    var canvas = document.createElement('canvas'); canvas.width = canvas.height = side;
    var ctx = canvas.getContext('2d'), pixels = ctx.createImageData(side, side);
    var patches = new Float32Array(stride * stride);
    // A shared world-pixel origin and halo make adjoining tiles seamless.
    for (var y = -1; y <= side; y++) for (var x = -1; x <= side; x++) {
      var wx = startX + x, wy = startY + y;
      var broad = noise(wx / 54, wy / 54), fine = noise(wx / 11 + 37, wy / 11 + 71);
      var i = (y + 1) * stride + x + 1;
      patches[i] = broad * .7 + fine * .3;
    }
    var climate = [], grid = Math.ceil(side / 16) + 1;
    for (var gy = 0; gy < grid; gy++) for (var gx = 0; gx < grid; gx++) {
      climate.push(sample((startX + gx * 16) / density, (startY + gy * 16) / density, size));
    }
    function weather(x, y) {
      var gx = Math.floor(x / 16), gy = Math.floor(y / 16), tx = x / 16 - gx, ty = y / 16 - gy;
      var a = climate[gy * grid + gx], b = climate[gy * grid + gx + 1];
      var c = climate[(gy + 1) * grid + gx], d = climate[(gy + 1) * grid + gx + 1];
      return { grass:(a.grass*(1-tx)+b.grass*tx)*(1-ty)+(c.grass*(1-tx)+d.grass*tx)*ty };
    }
    for (var py = 0; py < side; py++) for (var px = 0; px < side; px++) {
      var p = weather(px, py), at = (py + 1) * stride + px + 1;
      var patch = patches[at];
      var grain = hash(startX + px, startY + py) - .5;
      // A softer meadow blend with visible soil clearings, inspired by the reference map.
      var grass = clamp(p.grass * .68 + (patch - .42) * .42);
      var soilShade = (patch - .5) * 22 + grain * 14;
      var land = [96 + grass * 23, 81 + grass * 51, 61 + grass * 18];
      var offset = (py * side + px) * 4;
      for (var c = 0; c < 3; c++) {
        var ground = land[c] + soilShade;
        pixels.data[offset + c] = Math.round(ground);
      }
      pixels.data[offset + 3] = 255;
    }
    ctx.putImageData(pixels, 0, 0);
    // Fine blades are drawn at world-anchored positions, including a halo across tile edges.
    ctx.lineCap = 'round';
    for (var by = Math.floor((startY - 8) / 5); by <= Math.ceil((startY + side + 8) / 5); by++) {
      for (var bx = Math.floor((startX - 8) / 5); bx <= Math.ceil((startX + side + 8) / 5); bx++) {
        var r = hash(bx + 931, by + 407), xx = bx * 5 + r * 5, yy = by * 5 + hash(bx, by + 23) * 5;
        var cl = sample(xx / density, yy / density, size);
        if (r > .15 + cl.grass * .43) continue;
        var dx = xx - startX, dy = yy - startY;
        for (var blade = 0; blade < 3; blade++) {
          var seed = hash(bx + blade * 103, by + 791), angle = seed * Math.PI * 2;
          var length = 2 + seed * 4, endX = dx + Math.cos(angle) * length, endY = dy + Math.sin(angle) * length;
          ctx.strokeStyle = blade === 0 ? 'rgba(32,45,21,.30)' : (seed > .65 ? 'rgba(176,166,104,.46)' : 'rgba(139,163,81,.52)');
          ctx.lineWidth = blade === 0 ? .9 : .55;
          ctx.beginPath(); ctx.moveTo(dx, dy); ctx.quadraticCurveTo(dx + Math.cos(angle+.35)*length*.6, dy + Math.sin(angle+.35)*length*.6, endX, endY); ctx.stroke();
        }
      }
    }
    // Sparse landmark clusters add visual variety without competing with city/resource markers.
    // They are inset from tile edges so neighboring chunks remain pixel-seamless.
    // Minimal canvas mocks used by terrain seam tests do not expose shape primitives.
    if (!ctx.fillRect) return canvas;
    for (var gy2 = 24; gy2 < side - 24; gy2 += 52) for (var gx2 = 24; gx2 < side - 24; gx2 += 52) {
      var seed2 = hash(Math.floor((startX + gx2) / 52) + 1701, Math.floor((startY + gy2) / 52) + 2309);
      var ox = (hash(gx2 + cx * 19, gy2 + cy * 23) - .5) * 22, oy = (hash(gx2 + 71, gy2 + 113) - .5) * 22;
      var dx2 = gx2 + ox, dy2 = gy2 + oy;
      if (seed2 < .18) {
        // Low rounded hill with a few exposed soil/rock facets.
        ctx.fillStyle = 'rgba(112,101,73,.25)'; ctx.fillRect(dx2-15, dy2-3, 30, 12);
        ctx.fillStyle = 'rgba(145,136,101,.28)'; ctx.fillRect(dx2-14, dy2-10, 28, 14);
        ctx.strokeStyle = 'rgba(91,82,61,.30)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(dx2 - 9, dy2 - 1); ctx.lineTo(dx2 - 2, dy2 - 7); ctx.lineTo(dx2 + 7, dy2 - 2); ctx.stroke();
      } else if (seed2 < .43) {
        // Small shrub thicket: layered sage circles with visible gaps.
        for (var shrub = 0; shrub < 4; shrub++) { var sx = dx2 + (hash(shrub + gx2, gy2) - .5) * 25, sy = dy2 + (hash(shrub + gy2, gx2) - .5) * 18; ctx.fillStyle = shrub % 2 ? 'rgba(74,100,57,.42)' : 'rgba(105,127,69,.38)'; ctx.fillRect(sx-5, sy-5, 10, 10); }
      } else if (seed2 < .62) {
        // A few readable woodland crowns, sparser than the grass texture.
        for (var tree = 0; tree < 3; tree++) { var tx2 = dx2 + (tree - 1) * 13, ty2 = dy2 + (tree % 2) * 7; ctx.fillStyle = 'rgba(47,76,43,.45)'; ctx.fillRect(tx2-8, ty2-8, 16, 16); ctx.fillStyle = 'rgba(104,130,72,.45)'; ctx.fillRect(tx2-7, ty2-8, 12, 12); }
      } else if (seed2 < .75) {
        // Tiny wetland pocket with a muted teal center and reed marks.
        ctx.fillStyle = 'rgba(76,116,104,.25)'; ctx.fillRect(dx2-14, dy2-8, 28, 16);
        ctx.strokeStyle = 'rgba(55,88,72,.40)'; ctx.lineWidth = 1; for (var reed = -2; reed <= 2; reed++) { ctx.beginPath(); ctx.moveTo(dx2 + reed * 7, dy2 + 7); ctx.lineTo(dx2 + reed * 8 + 3, dy2 - 5); ctx.stroke(); }
      }
    }
    return canvas;
  }
  G.MapTerrain = { create: create, createTile: createTile, tileSpan: tileSpan, density: density, padding: padding, region: region, sample: sample };
})(window.Game = window.Game || {});
